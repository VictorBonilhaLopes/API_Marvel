import axios from 'axios';
import md5 from 'crypto-js/md5';

const publicKey = '6537e9f84b702fe95a0bbd633b9ba70f';
const privateKey = '5015e251d4ff2cbcfec39e52c471397f36abbde0';

const getMarvelCharacters = async (name) => {
  const ts = Date.now().toString();
  const hash = md5(ts + privateKey + publicKey).toString();

  const url = `https://gateway.marvel.com/v1/public/characters?nameStartsWith=${name}&ts=${ts}&apikey=${publicKey}&hash=${hash}`;

  try {
    const response = await axios.get(url);
    return response.data.data.results;
  } catch (error) {
    console.error('Um personagem não encontrado foi achado, pesquisa nova deve ser feita!:', error);
    return [];
  }
};

export { getMarvelCharacters };
